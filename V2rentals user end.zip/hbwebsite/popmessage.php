<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>V2 Rentals- HOUSE</title> 
  <?php require('inc/links.php');  ?>
 
  
  
</head>
<body class="bg-light">


  <?php require('inc/header.php');  ?>
  <div class="my-5 px-4">
    <h2 class="fw-bold h-font text-center"> please contact us for more details</h2>
    <div class="h-line bg-dark"></div>
    
  </div>

  <?php require('inc/footer.php'); ?>




</body>
</html>